$(document).ready(function(){
	$('.car-slider').slick({
		slidesToShow: 5,
		slidesToScroll: 5,
		responsive: [
			{
				breakpoint: 768,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 3
				}
			},
		]
	});

	$('.clients-slider').slick({
		slidesToShow: 4,
		slidesToScroll: 4
	});
});